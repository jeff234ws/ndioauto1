
    navigator.keyboard.lock();
    document.onkeydown = function (e) {
    return false;
    }